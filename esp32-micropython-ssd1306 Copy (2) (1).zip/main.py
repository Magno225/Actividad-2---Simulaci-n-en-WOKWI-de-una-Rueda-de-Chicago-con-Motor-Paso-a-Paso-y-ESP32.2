from machine import Pin, I2C
import time
import ssd1306

# Definir pines para I2C
SCL_PIN = 22  # Pin de reloj (ajustar según tu dispositivo)
SDA_PIN = 21  # Pin de datos (ajustar según tu dispositivo)

# Configuración de la interfaz I2C
i2c = I2C(scl=Pin(SCL_PIN), sda=Pin(SDA_PIN), freq=400000)

# Inicialización de la pantalla OLED (SSD1306)
oled = ssd1306.SSD1306_I2C(128, 64, i2c)  # 128x64 píxeles, ajusta según tu pantalla

# Definir pines para el motor paso a paso
STEP_PIN = 18  # Pin de pasos
DIR_PIN = 19   # Pin de dirección

# Configuración de pines
step = Pin(STEP_PIN, Pin.OUT)
direction = Pin(DIR_PIN, Pin.OUT)

# Configuración del motor
STEPS_PER_REV = 200  # Pasos por revolución (ajústalo según tu motor)
SILLAS = 5          # Cantidad de sillas en la rueda

stepper_pos = 0  # Inicializa la variable de posición del motor

def move_stepper(direct, steps, delay):
    global stepper_pos
    direction.value(direct)  # Dirección del motor
    steps = abs(steps)
    for i in range(steps):
        step.value(1)
        time.sleep_us(delay)  # Retardo entre los pasos
        step.value(0)
        time.sleep_us(delay)  # Retardo entre los pasos
    # Actualizar la posición del motor
    if direct:
        stepper_pos += steps
    else:
        stepper_pos -= steps

def show_message(msg):
    """Muestra un mensaje en la pantalla OLED."""
    oled.fill(0)  # Limpia la pantalla
    oled.text(msg, 0, 0)  # Muestra el mensaje en la posición (0,0)
    oled.show()  # Actualiza la pantalla para que el mensaje sea visible

def ciclo_rueda():
    """Simula el movimiento de la rueda con carga y descarga de pasajeros."""
    for vueltas in range(1):  # Simular 5 vueltas completas
        print(f"Vuelta {vueltas + 1}")
        show_message(f"Vuelta {vueltas + 1}")  # Mostrar en OLED

        for i in range(SILLAS):
            print(f"Cargando pasajero en silla {i + 1}")
            show_message(f"Cargando silla {i + 1}")  # Mostrar en OLED
            time.sleep(1)  # Simula el tiempo de carga
            move_stepper(1, STEPS_PER_REV // SILLAS, 50)  # Mueve a la siguiente silla

        # Descarga de pasajeros
        for i in range(SILLAS):
            print(f"Descargando pasajero en silla {i + 1}")
            show_message(f"Descargando silla {i + 1}")  # Mostrar en OLED
            time.sleep(1)  # Simula el tiempo de descarga
            move_stepper(50, STEPS_PER_REV // SILLAS, 100)  # Mueve hacia atrás

    print("Ciclo terminado. Reiniciando...")
    show_message("Ciclo terminado. Reiniciando...")  # Mostrar en OLED
    time.sleep(3)  # Pausa antes de repetir el ciclo

# Dirección inicial
direction.value(1)  # Sentido de giro

while True:
    ciclo_rueda()  # Llamada al ciclo de carga y descarga
